USE research_repository;
ALTER TABLE departments ADD COLUMN code VARCHAR(30) NULL AFTER name, ADD COLUMN faculty VARCHAR(150) NULL AFTER code, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER faculty;
UPDATE departments SET code=CONCAT('DPT-',id), faculty=COALESCE(faculty,'Academic Affairs') WHERE code IS NULL;
ALTER TABLE departments ADD UNIQUE KEY uq_departments_code (code);
ALTER TABLE programmes ADD COLUMN code VARCHAR(40) NULL AFTER name, ADD COLUMN degree_type VARCHAR(60) NULL AFTER code, ADD COLUMN duration VARCHAR(30) NULL AFTER degree_type, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER duration;
UPDATE programmes SET code=CONCAT('PRG-',id), degree_type='B.Sc.', duration='4 Years' WHERE code IS NULL;
ALTER TABLE programmes ADD UNIQUE KEY uq_programmes_code (code);
ALTER TABLE supervisors ADD COLUMN staff_id VARCHAR(50) NULL AFTER name, ADD COLUMN phone VARCHAR(30) NULL AFTER email, ADD COLUMN academic_rank VARCHAR(80) NULL AFTER phone, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER academic_rank, ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
UPDATE supervisors SET staff_id=CONCAT('STAFF-',id), academic_rank='Lecturer II' WHERE staff_id IS NULL;
ALTER TABLE supervisors ADD UNIQUE KEY uq_supervisors_staff_id (staff_id);
ALTER TABLE academic_sessions ADD COLUMN start_year SMALLINT NULL AFTER name, ADD COLUMN end_year SMALLINT NULL AFTER start_year, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'inactive' AFTER end_year;
UPDATE academic_sessions SET start_year=CAST(LEFT(name,4) AS UNSIGNED), end_year=CAST(RIGHT(name,4) AS UNSIGNED), status=IF(is_active=1,'active','inactive');
ALTER TABLE research_categories ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER description;
UPDATE research_categories SET status='active';
CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  type VARCHAR(60) NOT NULL,
  title VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  related_id INT UNSIGNED NULL,
  related_type VARCHAR(40) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user (user_id),
  INDEX idx_notifications_read (user_id, is_read),
  INDEX idx_notifications_created (created_at)
) ENGINE=InnoDB;
