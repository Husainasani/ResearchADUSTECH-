CREATE DATABASE IF NOT EXISTS research_repository CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE research_repository;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','student') NOT NULL DEFAULT 'student',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE departments (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL UNIQUE, description TEXT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE programmes (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, department_id INT UNSIGNED NULL, name VARCHAR(180) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE research_categories (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL UNIQUE, description TEXT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE academic_sessions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(30) NOT NULL UNIQUE, is_active TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE supervisors (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, email VARCHAR(190) NULL, department_id INT UNSIGNED NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE students (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL UNIQUE, matric_number VARCHAR(60) NOT NULL UNIQUE, phone VARCHAR(30) NOT NULL, department_id INT UNSIGNED NULL, programme_id INT UNSIGNED NULL, level VARCHAR(20) NOT NULL, session_id INT UNSIGNED NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL, FOREIGN KEY (programme_id) REFERENCES programmes(id) ON DELETE SET NULL, FOREIGN KEY (session_id) REFERENCES academic_sessions(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE research_projects (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, student_id INT UNSIGNED NOT NULL, department_id INT UNSIGNED NULL, programme_id INT UNSIGNED NULL, category_id INT UNSIGNED NULL, supervisor_id INT UNSIGNED NULL, session_id INT UNSIGNED NULL, title VARCHAR(255) NOT NULL, abstract TEXT NOT NULL, keywords VARCHAR(255) NOT NULL, pdf_filename VARCHAR(255) NOT NULL, original_filename VARCHAR(255) NOT NULL, status ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING', rejection_reason TEXT NULL, download_count INT UNSIGNED NOT NULL DEFAULT 0, submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, approved_at DATETIME NULL, rejected_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE RESTRICT, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL, FOREIGN KEY (programme_id) REFERENCES programmes(id) ON DELETE SET NULL, FOREIGN KEY (category_id) REFERENCES research_categories(id) ON DELETE SET NULL, FOREIGN KEY (supervisor_id) REFERENCES supervisors(id) ON DELETE SET NULL, FOREIGN KEY (session_id) REFERENCES academic_sessions(id) ON DELETE SET NULL, INDEX(title), INDEX(status), INDEX(student_id), INDEX(department_id), INDEX(category_id), INDEX(session_id)) ENGINE=InnoDB;
CREATE TABLE downloads (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, research_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NULL, ip_address VARCHAR(45) NOT NULL, user_agent VARCHAR(255) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (research_id) REFERENCES research_projects(id) ON DELETE RESTRICT, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL, INDEX(research_id), INDEX(created_at)) ENGINE=InnoDB;
CREATE TABLE activity_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NULL, action VARCHAR(60) NOT NULL, description VARCHAR(255) NOT NULL, ip_address VARCHAR(45) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL, INDEX(action), INDEX(created_at)) ENGINE=InnoDB;
CREATE TABLE notifications (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, type VARCHAR(60) NOT NULL, title VARCHAR(180) NOT NULL, message TEXT NOT NULL, related_id INT UNSIGNED NULL, related_type VARCHAR(40) NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX(user_id), INDEX(is_read), INDEX(created_at), INDEX(type)) ENGINE=InnoDB;
CREATE TABLE settings (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(100) NOT NULL UNIQUE, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB;

INSERT INTO departments (name, description) VALUES ('Computer Science','Computing and information systems research'),('Information Technology','Applied technology and digital transformation'),('Software Engineering','Software design, quality and delivery'),('Information and Media Studies','Information, communication and media research'),('Library and Information Science','Knowledge organization and library services');
INSERT INTO programmes (department_id,name) SELECT id, CONCAT(name, ' (B.Sc.)') FROM departments;
INSERT INTO research_categories (name,description) VALUES ('Information Systems','Systems, data and digital services'),('Software Development','Applications, platforms and engineering'),('Artificial Intelligence','Machine learning and intelligent systems'),('Networking and Security','Networks, infrastructure and cyber security'),('Library and Knowledge Services','Libraries, information and knowledge management');
INSERT INTO academic_sessions (name,is_active) VALUES ('2025/2026',1),('2024/2025',0),('2023/2024',0);
INSERT INTO supervisors (name,email,department_id) SELECT 'Dr. Amina Yusuf','amina.yusuf@adustech.edu.ng',id FROM departments WHERE name='Computer Science';
INSERT INTO supervisors (name,email,department_id) SELECT 'Dr. Ibrahim Musa','ibrahim.musa@adustech.edu.ng',id FROM departments WHERE name='Software Engineering';
INSERT INTO users (name,email,password,role,status) VALUES ('System Administrator','admin@adustech.edu.ng','$2y$10$QINNKfntMfD67U8Z73AtbOijbR7/bIYhvhMSw2a/5J5hLaMBDXgN.','admin','active');

ALTER TABLE departments ADD COLUMN code VARCHAR(30) NULL AFTER name, ADD COLUMN faculty VARCHAR(150) NULL AFTER code, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER faculty;
UPDATE departments SET code=CONCAT('DPT-',id), faculty=COALESCE(faculty,'Academic Affairs') WHERE code IS NULL;
ALTER TABLE departments ADD UNIQUE KEY uq_departments_code (code);
ALTER TABLE programmes ADD COLUMN code VARCHAR(40) NULL AFTER name, ADD COLUMN degree_type VARCHAR(60) NULL AFTER code, ADD COLUMN duration VARCHAR(30) NULL AFTER degree_type, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER duration;
UPDATE programmes SET code=CONCAT('PRG-',id), degree_type='B.Sc.', duration='4 Years' WHERE code IS NULL;
ALTER TABLE programmes ADD UNIQUE KEY uq_programmes_code (code);
ALTER TABLE supervisors ADD COLUMN staff_id VARCHAR(50) NULL AFTER name, ADD COLUMN phone VARCHAR(30) NULL AFTER email, ADD COLUMN academic_rank VARCHAR(80) NULL AFTER phone, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER academic_rank, ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
UPDATE supervisors SET staff_id=CONCAT('STAFF-',id), academic_rank='Lecturer II' WHERE staff_id IS NULL;
ALTER TABLE supervisors ADD UNIQUE KEY uq_supervisors_staff_id (staff_id);
ALTER TABLE academic_sessions ADD COLUMN start_year SMALLINT NULL AFTER name, ADD COLUMN end_year SMALLINT NULL AFTER start_year, ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'inactive' AFTER end_year;
UPDATE academic_sessions SET start_year=CAST(LEFT(name,4) AS UNSIGNED), end_year=CAST(RIGHT(name,4) AS UNSIGNED), status=IF(is_active=1,'active','inactive');
ALTER TABLE research_categories ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active' AFTER description;
UPDATE research_categories SET status='active';

