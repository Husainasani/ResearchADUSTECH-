<?php
require __DIR__ . '/config/functions.php';
$pageTitle = 'Browse Research';
$q = trim(isset($_GET['q']) ? $_GET['q'] : '');
$departmentId = isset($_GET['department_id']) ? (int)$_GET['department_id'] : 0;
$sessionId = isset($_GET['session_id']) ? (int)$_GET['session_id'] : 0;
$page = max(1, (int)(isset($_GET['page']) ? $_GET['page'] : 1));
$limit = 12;
$offset = ($page - 1) * $limit;
$where = ["r.status='APPROVED'"];
$params = [];
if ($q !== '') {
    $where[] = '(r.title LIKE ? OR r.abstract LIKE ? OR r.keywords LIKE ? OR u.name LIKE ? OR d.name LIKE ?)';
    for ($i = 0; $i < 5; $i++) { $params[] = '%' . $q . '%'; }
}
if ($departmentId > 0) { $where[] = 'r.department_id=?'; $params[] = $departmentId; }
if ($sessionId > 0) { $where[] = 'r.session_id=?'; $params[] = $sessionId; }
$whereSql = implode(' AND ', $where);
$count = $pdo->prepare("SELECT COUNT(*) FROM research_projects r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id LEFT JOIN departments d ON d.id=r.department_id LEFT JOIN academic_sessions a ON a.id=r.session_id WHERE $whereSql");
$count->execute($params);
$total = (int)$count->fetchColumn();
$stmt = $pdo->prepare("SELECT r.id,r.title,r.abstract,r.keywords,r.submitted_at,r.download_count,u.name author,d.name department,c.name category,a.name session_name FROM research_projects r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id LEFT JOIN departments d ON d.id=r.department_id LEFT JOIN research_categories c ON c.id=r.category_id LEFT JOIN academic_sessions a ON a.id=r.session_id WHERE $whereSql ORDER BY r.approved_at DESC LIMIT $limit OFFSET $offset");
$stmt->execute($params);
$rows = $stmt->fetchAll();
$departments = $pdo->query("SELECT id,name FROM departments WHERE status='active' ORDER BY name")->fetchAll();
$sessions = $pdo->query("SELECT id,name FROM academic_sessions WHERE status='active' ORDER BY name DESC")->fetchAll();
$pages = max(1, (int)ceil($total / $limit));
require __DIR__ . '/includes/header.php';
?>
<section class="mx-auto max-w-7xl px-5 py-12"><div class="max-w-3xl"><p class="text-sm font-bold uppercase tracking-widest text-leaf">Public collection</p><h1 class="mt-2 text-4xl font-black text-forest">Browse research</h1><p class="mt-3 text-slate-600">Search approved undergraduate projects by title, department, session or keyword.</p></div><form method="get" class="mt-8 grid max-w-4xl gap-3 md:grid-cols-[1.5fr_1fr_1fr_auto]"><input name="q" value="<?= e($q) ?>" class="field" placeholder="Search the repository"><select name="department_id" class="field"><option value="">All departments</option><?php foreach ($departments as $department): ?><option value="<?= (int)$department['id'] ?>" <?= $departmentId === (int)$department['id'] ? 'selected' : '' ?>><?= e($department['name']) ?></option><?php endforeach; ?></select><select name="session_id" class="field"><option value="">All sessions</option><?php foreach ($sessions as $session): ?><option value="<?= (int)$session['id'] ?>" <?= $sessionId === (int)$session['id'] ? 'selected' : '' ?>><?= e($session['name']) ?></option><?php endforeach; ?></select><button class="rounded-lg bg-forest px-5 font-bold text-white">Filter</button></form><div class="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3"><?php foreach ($rows as $row): ?><article class="flex flex-col rounded-xl border border-emerald-100 bg-white p-5"><div class="flex items-start justify-between gap-3"><span class="text-xs font-bold uppercase text-leaf"><?= e(isset($row['category']) ? $row['category'] : 'Research') ?></span><span class="text-xs text-slate-400"><?= e(isset($row['session_name']) ? $row['session_name'] : '') ?></span></div><h2 class="mt-3 text-lg font-bold leading-6 text-forest"><a href="/001/research-details.php?id=<?= (int)$row['id'] ?>" class="hover:text-leaf"><?= e($row['title']) ?></a></h2><p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-600"><?= e($row['abstract']) ?></p><div class="mt-auto pt-5 text-xs text-slate-500"><?= e(isset($row['department']) ? $row['department'] : '') ?> &middot; <?= e($row['author']) ?></div></article><?php endforeach; if (!$rows): ?><div class="rounded-xl bg-white p-8 text-slate-500 md:col-span-3">No research projects found.</div><?php endif; ?></div><?php if ($pages > 1): ?><div class="mt-8 flex gap-2"><?php for ($i = 1; $i <= $pages; $i++): ?><a class="rounded-lg px-3 py-2 <?= $i === $page ? 'bg-forest text-white' : 'bg-white text-forest' ?>" href="?q=<?= urlencode($q) ?>&department_id=<?= (int)$departmentId ?>&session_id=<?= (int)$sessionId ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor; ?></div><?php endif; ?></section><?php require __DIR__ . '/includes/footer.php'; ?>