<?php
require __DIR__ . '/../config/functions.php';
require_admin();

$pageTitle = 'Duplicate-Topic Screening';
$topic = trim((string)(isset($_POST['topic']) ? $_POST['topic'] : ''));
$departmentId = isset($_POST['department_id']) ? (int)$_POST['department_id'] : 0;
$sessionId = isset($_POST['session_id']) ? (int)$_POST['session_id'] : 0;
$similarityThreshold = 50;
$error = '';
$results = [];
$summary = ['status' => 'no_match', 'message' => 'No closely related research topic was found.', 'detail' => 'This result is only a basic topic similarity check and does not constitute a plagiarism determination.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if ($topic === '') {
        $error = 'Please enter a research topic to continue.';
    } else {
        $results = find_similar_research_topics($topic, $departmentId, $sessionId, 20, $similarityThreshold);
        $summary = topic_check_summary($results, $topic);
    }
}

$departments = $pdo->query("SELECT id,name FROM departments WHERE status='active' ORDER BY name")->fetchAll();
$sessions = $pdo->query("SELECT id,name FROM academic_sessions WHERE status='active' ORDER BY name DESC")->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<section class="mx-auto max-w-6xl px-5 py-10">
  <div class="rounded-2xl border border-emerald-100 bg-white p-7 shadow-sm">
    <div class="flex items-center gap-3">
      <span class="grid h-12 w-12 place-items-center rounded-xl bg-emerald-50 text-forest"><i data-lucide="search-check" class="h-6 w-6"></i></span>
      <div>
        <p class="text-sm font-bold uppercase tracking-widest text-leaf">Research administration</p>
        <h1 class="mt-1 text-3xl font-black text-forest">Duplicate-Topic Screening</h1>
      </div>
    </div>
    <p class="mt-4 max-w-3xl text-slate-600">Check whether a proposed research topic is already existing or closely related to previous research projects.</p>

    <form method="post" class="mt-8 grid gap-4 md:grid-cols-4">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <div class="md:col-span-2">
        <label class="text-sm font-semibold text-slate-700">Research Topic</label>
        <textarea name="topic" rows="5" class="field mt-2" placeholder="Enter proposed research topic..."><?= e($topic) ?></textarea>
      </div>
      <div>
        <label class="text-sm font-semibold text-slate-700">Department</label>
        <select name="department_id" class="field mt-2">
          <option value="0">Search all departments</option>
          <?php foreach ($departments as $department): ?>
            <option value="<?= (int)$department['id'] ?>" <?= $departmentId === (int)$department['id'] ? 'selected' : '' ?>><?= e($department['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="text-sm font-semibold text-slate-700">Academic Session</label>
        <select name="session_id" class="field mt-2">
          <option value="0">All Sessions</option>
          <?php foreach ($sessions as $session): ?>
            <option value="<?= (int)$session['id'] ?>" <?= $sessionId === (int)$session['id'] ? 'selected' : '' ?>><?= e($session['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="md:col-span-4 flex items-end justify-end">
        <button type="submit" class="inline-flex items-center gap-2 rounded-lg bg-forest px-5 py-3 font-bold text-white"><i data-lucide="search-check" class="h-4 w-4"></i> Check Similar Topics</button>
      </div>
    </form>

    <?php if ($error): ?>
      <div class="mt-6 rounded-lg bg-red-50 p-3 text-sm text-red-700"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error): ?>
      <div class="mt-8 rounded-xl border border-emerald-100 bg-emerald-50 p-4">
        <div class="flex items-start justify-between gap-3">
          <div>
            <h2 class="text-lg font-black text-forest"><?= e($summary['message']) ?></h2>
            <p class="mt-1 text-sm text-slate-700"><?= e($summary['detail']) ?></p>
          </div>
          <?php if ($results): ?>
            <span class="inline-flex rounded-full bg-white px-3 py-1 text-xs font-bold uppercase tracking-wider text-forest">Similarity threshold: <?= (int)$similarityThreshold ?>%</span>
          <?php endif; ?>
        </div>
      </div>

      <?php if ($results): ?>
        <div class="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div class="overflow-x-auto">
            <table class="w-full min-w-[900px] text-left text-sm">
              <thead class="bg-mist text-xs uppercase tracking-wider text-slate-500">
                <tr>
                  <th class="p-4">Research Title</th>
                  <th class="p-4">Department</th>
                  <th class="p-4">Programme</th>
                  <th class="p-4">Academic Session</th>
                  <th class="p-4">Similarity</th>
                  <th class="p-4">Status</th>
                  <th class="p-4">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($results as $row): ?>
                  <tr class="border-t border-slate-100">
                    <td class="p-4 font-medium text-forest"><?= e($row['title']) ?></td>
                    <td class="p-4"><?= e($row['department'] ?: 'N/A') ?></td>
                    <td class="p-4"><?= e($row['programme'] ?: 'N/A') ?></td>
                    <td class="p-4"><?= e($row['session_name'] ?: 'N/A') ?></td>
                    <td class="p-4"><span class="rounded-full bg-amber-100 px-2 py-1 text-xs font-bold text-amber-700"><?= (int)$row['similarity'] ?>%</span></td>
                    <td class="p-4"><span class="<?= e(status_class($row['status'])) ?>"><?= e($row['status']) ?></span></td>
                    <td class="p-4"><a href="/001/research-details.php?id=<?= (int)$row['id'] ?>" class="rounded-lg bg-forest px-3 py-2 font-bold text-white">View</a></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      <?php else: ?>
        <div class="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5 text-slate-600">
          <p class="font-semibold text-slate-700">No closely related research topic was found.</p>
          <p class="mt-2 text-sm">This result is only a basic topic similarity check and does not constitute a plagiarism determination.</p>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
