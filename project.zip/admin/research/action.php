<?php
require __DIR__ . '/../../config/functions.php';
require_admin();
$id = (int)(isset($_GET['id']) ? $_GET['id'] : (isset($_POST['id']) ? $_POST['id'] : 0));
if (isset($_GET['reject'])) {
    $stmt = $pdo->prepare('SELECT id,title FROM research_projects WHERE id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) { redirect('index.php'); }
    $pageTitle = 'Reject research';
    require __DIR__ . '/../../includes/header.php';
    ?><section class="mx-auto max-w-xl px-5 py-12"><div class="rounded-2xl border border-emerald-100 bg-white p-7"><h1 class="text-2xl font-black text-forest">Reject research</h1><p class="mt-2 text-sm text-slate-500"><?= e($row['title']) ?></p><form method="post" class="mt-6 space-y-4"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= (int)$id ?>"><input type="hidden" name="action" value="reject"><label class="text-sm font-semibold">Rejection reason<textarea required name="reason" rows="5" class="field mt-2"></textarea></label><button class="w-full rounded-lg bg-red-700 px-4 py-3 font-bold text-white">Reject research</button></form></div></section><?php require __DIR__ . '/../../includes/footer.php'; exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('index.php'); }
verify_csrf();
$action = isset($_POST['action']) ? $_POST['action'] : '';
$reason = trim(isset($_POST['reason']) ? $_POST['reason'] : '');
if ($action === 'approve') {
    $pdo->prepare("UPDATE research_projects SET status='APPROVED',approved_at=NOW(),rejected_at=NULL,rejection_reason=NULL WHERE id=?")->execute([$id]);
    log_activity(current_user()['id'], 'APPROVE_RESEARCH', 'Approved research #' . $id);
    flash('success', 'Research approved successfully.');
} elseif ($action === 'reject' && $reason !== '') {
    $pdo->prepare("UPDATE research_projects SET status='REJECTED',rejected_at=NOW(),approved_at=NULL,rejection_reason=? WHERE id=?")->execute([$reason, $id]);
    log_activity(current_user()['id'], 'REJECT_RESEARCH', 'Rejected research #' . $id);
    flash('success', 'Research rejected.');
} else {
    flash('error', 'A rejection reason is required.');
}
redirect('index.php');