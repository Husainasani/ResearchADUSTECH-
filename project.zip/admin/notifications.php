<?php
require __DIR__ . '/../config/functions.php';
require_admin();

$userId = current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['notification_id'])) {
        mark_notification_read((int)$_POST['notification_id'], $userId);
    }
    if (isset($_POST['mark_all']) && (int)$_POST['mark_all'] === 1) {
        mark_all_notifications_read($userId);
    }
    redirect('notifications.php');
}

$notifications = get_notifications($userId, 100);
$pageTitle = 'Notifications';
require __DIR__ . '/../includes/header.php';
?>
<section class="mx-auto max-w-5xl px-5 py-10">
    <div class="flex items-center justify-between gap-4">
        <div>
            <p class="text-sm font-bold uppercase tracking-widest text-leaf">Administration</p>
            <h1 class="mt-2 text-3xl font-black text-forest">Notifications</h1>
        </div>
        <form method="post" class="inline-block">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="mark_all" value="1">
            <button type="submit" class="rounded-lg border border-emerald-200 px-4 py-2 text-sm font-bold text-forest">Mark all as read</button>
        </form>
    </div>

    <div class="mt-6 space-y-4">
        <?php if (!$notifications): ?>
            <div class="rounded-xl border border-emerald-100 bg-white p-6 text-slate-500">No notifications yet.</div>
        <?php else: ?>
            <?php foreach ($notifications as $notification): ?>
                <div class="rounded-xl border <?= (int)$notification['is_read'] ? 'border-slate-200 bg-white' : 'border-leaf/30 bg-emerald-50' ?> p-4">
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <p class="text-sm font-bold text-forest"><?= e($notification['title']) ?></p>
                            <p class="mt-2 text-sm text-slate-600"><?= nl2br(e($notification['message'])) ?></p>
                            <p class="mt-2 text-xs text-slate-500"><?= e(date('d M Y, h:i A', strtotime($notification['created_at']))) ?></p>
                        </div>
                        <?php if (!(int)$notification['is_read']): ?>
                            <form method="post">
                                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                                <input type="hidden" name="notification_id" value="<?= (int)$notification['id'] ?>">
                                <button type="submit" class="rounded-lg bg-forest px-3 py-2 text-xs font-bold text-white">Mark read</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
