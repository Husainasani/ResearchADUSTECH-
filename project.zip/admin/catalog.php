<?php
$type = isset($_GET['type']) ? $_GET['type'] : 'departments';
header('Location: /001/admin/academic.php?type=' . urlencode($type));
exit;
