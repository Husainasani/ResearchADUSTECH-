<?php
require __DIR__ . '/../config/functions.php';
$error = '';
$departments = $pdo->query("SELECT id,name FROM departments WHERE status='active' ORDER BY name")->fetchAll();
$programmes = $pdo->query("SELECT id,name,department_id FROM programmes WHERE status='active' ORDER BY name")->fetchAll();
$sessions = $pdo->query("SELECT id,name FROM academic_sessions WHERE status='active' ORDER BY name DESC")->fetchAll();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
    $matric = trim(isset($_POST['matric_number']) ? $_POST['matric_number'] : '');
    $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $phone = trim(isset($_POST['phone']) ? $_POST['phone'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $password !== $confirm) {
        $error = 'Complete all fields correctly. Passwords must match and contain at least 8 characters.';
    } else {
        $academicError = validate_academic_selection(isset($_POST['department_id']) ? $_POST['department_id'] : null, isset($_POST['programme_id']) ? $_POST['programme_id'] : null, null, null, isset($_POST['session_id']) ? $_POST['session_id'] : null);
        if ($academicError !== '') { $error = $academicError; }
    }
    if (!$error) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('INSERT INTO users (name,email,password) VALUES (?,?,?)');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            $uid = (int)$pdo->lastInsertId();
            $departmentId = !empty($_POST['department_id']) ? $_POST['department_id'] : null;
            $programmeId = !empty($_POST['programme_id']) ? $_POST['programme_id'] : null;
            $sessionId = !empty($_POST['session_id']) ? $_POST['session_id'] : null;
            $level = isset($_POST['level']) ? $_POST['level'] : '';
            $stmt = $pdo->prepare('INSERT INTO students (user_id,matric_number,phone,department_id,programme_id,level,session_id) VALUES (?,?,?,?,?,?,?)');
            $stmt->execute([$uid, $matric, $phone, $departmentId, $programmeId, $level, $sessionId]);
            $pdo->commit();
            log_activity($uid, 'REGISTER', 'Student account created');
            flash('success', 'Registration successful. Please sign in.');
            redirect('/001/auth/login.php');
        } catch (Exception $exception) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $error = 'Email or matric number may already be registered.';
        }
    }
}
$pageTitle = 'Student registration';
require __DIR__ . '/../includes/header.php';
?>
<section class="mx-auto max-w-3xl px-5 py-12"><div class="rounded-2xl border border-emerald-100 bg-white p-7"><p class="text-sm font-bold uppercase tracking-widest text-leaf">Student access</p><h1 class="mt-2 text-3xl font-black text-forest">Create your account</h1><?php if ($error): ?><div class="mt-5 rounded-lg bg-red-50 p-3 text-sm text-red-700"><?= e($error) ?></div><?php endif; ?><form method="post" class="mt-6 grid gap-4 md:grid-cols-2"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><label class="text-sm font-semibold md:col-span-2">Full name<input required name="name" class="field mt-2"></label><label class="text-sm font-semibold">Matric number<input required name="matric_number" class="field mt-2"></label><label class="text-sm font-semibold">Email<input required type="email" name="email" class="field mt-2"></label><label class="text-sm font-semibold">Phone<input required name="phone" class="field mt-2"></label><label class="text-sm font-semibold">Level<select required name="level" class="field mt-2"><option value="100">100</option><option value="200">200</option><option value="300">300</option><option value="400">400</option><option value="500">500</option></select></label><label class="text-sm font-semibold">Department<select name="department_id" class="field mt-2"><option value="">Select department</option><?php foreach ($departments as $department): ?><option value="<?= $department['id'] ?>"><?= e($department['name']) ?></option><?php endforeach; ?></select></label><label class="text-sm font-semibold">Programme<select name="programme_id" class="field mt-2"><option value="">Select programme</option><?php foreach ($programmes as $programme): ?><option value="<?= $programme['id'] ?>"><?= e($programme['name']) ?></option><?php endforeach; ?></select></label><label class="text-sm font-semibold">Academic session<select name="session_id" class="field mt-2"><option value="">Select session</option><?php foreach ($sessions as $session): ?><option value="<?= $session['id'] ?>"><?= e($session['name']) ?></option><?php endforeach; ?></select></label><label class="text-sm font-semibold">Password<input required minlength="8" type="password" name="password" class="field mt-2"></label><label class="text-sm font-semibold">Confirm password<input required minlength="8" type="password" name="confirm_password" class="field mt-2"></label><button class="rounded-lg bg-forest px-4 py-3 font-bold text-white md:col-span-2">Create account</button></form></div></section><?php require __DIR__ . '/../includes/footer.php'; ?>