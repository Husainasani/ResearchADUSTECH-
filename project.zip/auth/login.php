<?php
require __DIR__ . '/../config/functions.php';
$user = current_user();
if ($user) { redirect('/001/' . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'student/dashboard.php')); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $identity = trim(isset($_POST['identity']) ? $_POST['identity'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    if ($identity === '') {
        $error = 'Please enter your email or matric number.';
    } elseif ($password === '') {
        $error = 'Please enter your password.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE (email=? OR id IN (SELECT user_id FROM students WHERE matric_number=?)) LIMIT 1");
        $stmt->execute([$identity, $identity]);
        $loggedInUser = $stmt->fetch();
        if (!$loggedInUser || $loggedInUser['status'] !== 'active' || !password_verify($password, $loggedInUser['password'])) {
            $error = 'Invalid login credentials or inactive account.';
        } else {
            login_user($loggedInUser);
            log_activity((int)$loggedInUser['id'], 'LOGIN', 'User signed in');
            redirect('/001/' . ($loggedInUser['role'] === 'admin' ? 'admin/dashboard.php' : 'student/dashboard.php'));
        }
    }
    $error = 'Incorrect login credentials.';
}
$pageTitle = 'Sign in';
require __DIR__ . '/../includes/header.php';
?>
<section class="mx-auto max-w-md px-5 py-16"><div class="rounded-2xl border border-emerald-100 bg-white p-7 shadow-sm"><p class="text-sm font-bold uppercase tracking-widest text-leaf">ADUSTECH portal</p><h1 class="mt-2 text-3xl font-black text-forest">Sign in</h1><?php if ($error): ?><div class="mt-5 rounded-lg bg-red-50 p-3 text-sm text-red-700"><?= e($error) ?></div><?php endif; ?><form method="post" class="mt-6 space-y-4"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><label class="block text-sm font-semibold">Email or matric number<input required name="identity" class="field mt-2" placeholder="you@example.com or matric number"></label><label class="block text-sm font-semibold">Password<div class="mt-2 flex gap-2"><input required id="password" type="password" name="password" class="field"><button type="button" data-password-toggle="#password" class="rounded-lg border px-3" aria-label="Show password"><i data-lucide="eye"></i></button></div></label><label class="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" name="remember" value="1" class="h-4 w-4"> Remember me</label><button class="w-full rounded-lg bg-forest px-4 py-3 font-bold text-white">Sign in</button></form><p class="mt-5 text-sm text-slate-500">Don't have an account? <a class="font-bold text-leaf" href="register.php">Create an account</a></p></div></section><?php require __DIR__ . '/../includes/footer.php'; ?>