<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
function current_user() { return isset($_SESSION['user']) ? $_SESSION['user'] : null; }
function require_login() { if (!current_user()) { header('Location: /001/auth/login.php'); exit; } }
function require_role($role) { require_login(); $user = current_user(); if ((isset($user['role']) ? $user['role'] : '') !== $role) { http_response_code(403); require __DIR__ . '/../403.php'; exit; } }
function require_admin() { require_role('admin'); }
function require_student() { require_role('student'); }
function login_user(array $user) { session_regenerate_id(true); $_SESSION['user'] = ['id'=>(int)$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']]; }
function logout_user() { $_SESSION=[]; if (ini_get('session.use_cookies')) { $params=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$params['path'],$params['domain'],$params['secure'],$params['httponly']); } session_destroy(); }
