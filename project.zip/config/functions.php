<?php
date_default_timezone_set('Africa/Lagos');
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/auth.php';
function e($value) { return htmlspecialchars(isset($value) ? $value : '', ENT_QUOTES, 'UTF-8'); }
function csrf_token() { if (empty($_SESSION['csrf'])) { if (function_exists('random_bytes')) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); } elseif (function_exists('openssl_random_pseudo_bytes')) { $_SESSION['csrf'] = bin2hex(openssl_random_pseudo_bytes(32)); } else { $_SESSION['csrf'] = hash('sha256', uniqid(mt_rand(), true) . microtime(true)); } } return $_SESSION['csrf']; }
function verify_csrf() { $token = isset($_POST['csrf']) ? $_POST['csrf'] : (isset($_GET['csrf']) ? $_GET['csrf'] : ''); $stored = isset($_SESSION['csrf']) ? $_SESSION['csrf'] : ''; if (!hash_equals($stored, $token)) { http_response_code(419); exit('Invalid request token.'); } }
function flash($type,$message) { $_SESSION['flash'] = compact('type','message'); }
function get_flash() { $flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : null; unset($_SESSION['flash']); return $flash; }
function log_activity($userId,$action,$description) { global $pdo; $stmt=$pdo->prepare('INSERT INTO activity_logs (user_id,action,description,ip_address) VALUES (?,?,?,?)'); $stmt->execute([$userId,$action,$description,isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '']); }
function redirect($path) { header('Location: ' . $path); exit; }
function status_class($status) { $classes = ['APPROVED'=>'badge-approved','REJECTED'=>'badge-rejected','PENDING'=>'badge-pending']; return isset($classes[$status]) ? $classes[$status] : 'badge-pending'; }
function clean_filename($name) { return preg_replace('/[^A-Za-z0-9._-]/','_',basename($name)); }
function ensure_notifications_table() {
	global $pdo;
	try {
		$stmt = $pdo->query("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'notifications' LIMIT 1");
		if ($stmt && $stmt->fetchColumn()) {
			return true;
		}
	} catch (Exception $e) {
		// Ignore schema lookup failures and create the table below.
	}

	try {
		$pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
			id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			user_id INT UNSIGNED NOT NULL,
			type VARCHAR(60) NOT NULL,
			title VARCHAR(180) NOT NULL,
			message TEXT NOT NULL,
			related_id INT UNSIGNED NULL,
			related_type VARCHAR(40) NULL,
			is_read TINYINT(1) NOT NULL DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_notifications_user (user_id),
			INDEX idx_notifications_read (user_id, is_read),
			INDEX idx_notifications_created (created_at)
		) ENGINE=InnoDB");
		return true;
	} catch (Exception $e) {
		return false;
	}
}
function create_notification($userId, $type, $title, $message, $relatedId = null, $relatedType = null) {
	global $pdo;
	if (!ensure_notifications_table()) { return; }
	$userId = (int)$userId;
	$relatedId = $relatedId !== null ? (int)$relatedId : null;
	if ($relatedId !== null && $relatedType !== null) {
		$stmt = $pdo->prepare("INSERT INTO notifications (user_id,type,title,message,related_id,related_type,is_read) SELECT ?,?,?,?,?,?,0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM notifications WHERE user_id=? AND type=? AND related_type=? AND related_id=? AND is_read=0)");
		$stmt->execute([$userId, $type, $title, $message, $relatedId, $relatedType, $userId, $type, $relatedType, $relatedId]);
		return;
	}
	$stmt = $pdo->prepare('INSERT INTO notifications (user_id,type,title,message,related_id,related_type,is_read) VALUES (?,?,?,?,?,?,0)');
	$stmt->execute([$userId, $type, $title, $message, null, null]);
}
function get_notifications($userId, $limit = 10) {
	global $pdo;
	if (!ensure_notifications_table()) { return []; }
	$stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?');
	$stmt->bindValue(1, (int)$userId, PDO::PARAM_INT);
	$stmt->bindValue(2, (int)$limit, PDO::PARAM_INT);
	$stmt->execute();
	return $stmt->fetchAll();
}
function unread_notification_count($userId) {
	global $pdo;
	if (!ensure_notifications_table()) { return 0; }
	$stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0');
	$stmt->execute([(int)$userId]);
	return (int)$stmt->fetchColumn();
}
function mark_notification_read($notificationId, $userId = null) {
	global $pdo;
	if (!ensure_notifications_table()) { return; }
	if ($userId !== null) {
		$stmt = $pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?');
		$stmt->execute([(int)$notificationId, (int)$userId]);
		return;
	}
	$stmt = $pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=?');
	$stmt->execute([(int)$notificationId]);
}
function mark_all_notifications_read($userId) {
	global $pdo;
	if (!ensure_notifications_table()) { return; }
	$stmt = $pdo->prepare('UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0');
	$stmt->execute([(int)$userId]);
}
function notify_admins_of_research_submission($researchId, $title, $departmentName, $sessionName, $studentName) {
	global $pdo;
	$adminStmt = $pdo->prepare("SELECT id FROM users WHERE role='admin' AND status='active'");
	$adminStmt->execute();
	$admins = $adminStmt->fetchAll();
	if (!$admins) { return; }
	$message = "Research title: " . $title . "\nSubmitted by: " . $studentName . "\nDepartment: " . $departmentName . "\nAcademic Session: " . $sessionName;
	foreach ($admins as $admin) {
		create_notification((int)$admin['id'], 'new_research_submission', 'New research project submitted', $message, (int)$researchId, 'research');
	}
}
function validate_academic_selection($departmentId, $programmeId, $supervisorId, $categoryId, $sessionId) {
	global $pdo;
	if ($departmentId !== null && $departmentId !== '') {
		$stmt = $pdo->prepare("SELECT id FROM departments WHERE id=? AND status='active'"); $stmt->execute([$departmentId]); if (!$stmt->fetchColumn()) return 'Please select a valid active department.';
	}
	if ($programmeId !== null && $programmeId !== '') {
		$stmt = $pdo->prepare("SELECT id FROM programmes WHERE id=? AND status='active'"); $stmt->execute([$programmeId]); if (!$stmt->fetchColumn()) return 'Please select a valid active programme.';
		if ($departmentId !== null && $departmentId !== '') {
			$stmt = $pdo->prepare("SELECT id FROM programmes WHERE id=? AND department_id=? AND status='active'"); $stmt->execute([$programmeId, $departmentId]); if (!$stmt->fetchColumn()) return 'Please select a programme from the selected department.';
		}
	}
	if ($supervisorId !== null && $supervisorId !== '') {
		$stmt = $pdo->prepare("SELECT id FROM supervisors WHERE id=? AND status='active'"); $stmt->execute([$supervisorId]); if (!$stmt->fetchColumn()) return 'Please select a valid active supervisor.';
		if ($departmentId !== null && $departmentId !== '') {
			$stmt = $pdo->prepare("SELECT id FROM supervisors WHERE id=? AND department_id=? AND status='active'"); $stmt->execute([$supervisorId, $departmentId]); if (!$stmt->fetchColumn()) return 'Please select a supervisor assigned to the selected department.';
		}
	}
	if ($categoryId !== null && $categoryId !== '') { $stmt = $pdo->prepare("SELECT id FROM research_categories WHERE id=? AND status='active'"); $stmt->execute([$categoryId]); if (!$stmt->fetchColumn()) return 'Please select a valid active category.'; }
	if ($sessionId !== null && $sessionId !== '') { $stmt = $pdo->prepare("SELECT id FROM academic_sessions WHERE id=? AND status='active'"); $stmt->execute([$sessionId]); if (!$stmt->fetchColumn()) return 'Please select a valid active academic session.'; }
	return '';
}
function validate_research_submission($studentId, $departmentId, $programmeId, $supervisorId, $sessionId) {
	global $pdo;
	if (empty($studentId)) { return 'A valid student record is required.'; }
	if (empty($departmentId)) { return 'Please select a department.'; }
	$stmt = $pdo->prepare('SELECT department_id, programme_id FROM students WHERE id=? LIMIT 1');
	$stmt->execute([(int)$studentId]);
	$studentRow = $stmt->fetch();
	if (!$studentRow) { return 'Student record not found.'; }
	if (!empty($studentRow['department_id']) && (int)$studentRow['department_id'] !== (int)$departmentId) { return 'The selected department does not match the student profile.'; }
	if (!empty($programmeId)) {
		$stmt = $pdo->prepare("SELECT department_id FROM programmes WHERE id=? AND status='active' LIMIT 1");
		$stmt->execute([$programmeId]);
		$programmeDepartment = $stmt->fetchColumn();
		if (!$programmeDepartment) { return 'Please select a valid programme for the selected department.'; }
		if ((int)$programmeDepartment !== (int)$departmentId) { return 'Please select a programme from the selected department.'; }
		if (!empty($studentRow['programme_id']) && (int)$studentRow['programme_id'] !== (int)$programmeId && !empty($studentRow['department_id']) && (int)$studentRow['department_id'] === (int)$departmentId) {
			return 'The selected programme does not match the student profile for this department.';
		}
	}
	if (!empty($supervisorId)) {
		$stmt = $pdo->prepare("SELECT department_id FROM supervisors WHERE id=? AND status='active' LIMIT 1");
		$stmt->execute([$supervisorId]);
		$supervisorDepartment = $stmt->fetchColumn();
		if (!$supervisorDepartment) { return 'Please select a valid active supervisor.'; }
		if ((int)$supervisorDepartment !== (int)$departmentId) { return 'The selected supervisor must belong to the selected department.'; }
	}
	if (!empty($sessionId)) {
		$stmt = $pdo->prepare("SELECT id FROM academic_sessions WHERE id=? AND status='active' LIMIT 1");
		$stmt->execute([$sessionId]);
		if (!$stmt->fetchColumn()) { return 'Please select a valid active academic session.'; }
	}
	return '';
}

function normalize_topic_text($text) {
	$text = strtolower(trim((string)$text));
	$text = preg_replace('/[\p{P}\p{S}]+/u', ' ', $text);
	$text = preg_replace('/\s+/u', ' ', $text);
	return trim($text);
}

function extract_topic_keywords($text) {
	$normalized = normalize_topic_text($text);
	if ($normalized === '') { return []; }
	$stopWords = ['a','an','the','of','for','to','and','in','on','with','by','from','using','based','system','design','implementation','research','project','study','analysis','development','university','department','application','management','information','technology'];
	$words = preg_split('/\s+/u', $normalized);
	$keywords = [];
	foreach ($words as $word) {
		$word = trim($word);
		if ($word === '' || strlen($word) < 2 || in_array($word, $stopWords, true)) { continue; }
		$keywords[] = $word;
	}
	return array_values(array_unique($keywords));
}

function topic_similarity_score($leftTitle, $rightTitle) {
	$leftText = normalize_topic_text($leftTitle);
	$rightText = normalize_topic_text($rightTitle);
	if ($leftText === '' || $rightText === '') { return 0; }
	if ($leftText === $rightText) { return 100; }
	$leftWords = extract_topic_keywords($leftText);
	$rightWords = extract_topic_keywords($rightText);
	if (empty($leftWords) || empty($rightWords)) {
		$leftSet = array_unique(preg_split('/\s+/u', $leftText));
		$rightSet = array_unique(preg_split('/\s+/u', $rightText));
		$intersection = count(array_intersect($leftSet, $rightSet));
		$union = count(array_unique(array_merge($leftSet, $rightSet)));
		if ($union === 0) { return 0; }
		return round(($intersection / $union) * 100, 1);
	}
	$leftSet = array_fill_keys($leftWords, true);
	$rightSet = array_fill_keys($rightWords, true);
	$intersection = 0;
	foreach ($leftWords as $word) {
		if (isset($rightSet[$word])) { $intersection++; }
	}
	$union = array_unique(array_merge($leftWords, $rightWords));
	if (count($union) === 0) { return 0; }
	return round(($intersection / count($union)) * 100, 1);
}

function find_similar_research_topics($topic, $departmentId = 0, $sessionId = 0, $limit = 20, $similarityThreshold = 50) {
	global $pdo;
	$normalizedTopic = normalize_topic_text($topic);
	if ($normalizedTopic === '') { return []; }
	$where = ['r.status IN (\'APPROVED\',\'PENDING\')'];
	$params = [];
	if ((int)$departmentId > 0) {
		$where[] = 'r.department_id = ?';
		$params[] = (int)$departmentId;
	}
	if ((int)$sessionId > 0) {
		$where[] = 'r.session_id = ?';
		$params[] = (int)$sessionId;
	}
	$sql = "SELECT r.id, r.title, r.status, r.department_id, r.programme_id, r.session_id, d.name AS department, p.name AS programme, a.name AS session_name
		FROM research_projects r
		LEFT JOIN departments d ON d.id = r.department_id
		LEFT JOIN programmes p ON p.id = r.programme_id
		LEFT JOIN academic_sessions a ON a.id = r.session_id
		WHERE " . implode(' AND ', $where) . "
		ORDER BY r.submitted_at DESC
		LIMIT 200";
	$stmt = $pdo->prepare($sql);
	$stmt->execute($params);
	$rows = $stmt->fetchAll();
	$matches = [];
	foreach ($rows as $row) {
		$score = topic_similarity_score($normalizedTopic, $row['title']);
		if ($score < $similarityThreshold) { continue; }
		$matches[] = [
			'id' => (int)$row['id'],
			'title' => $row['title'],
			'department' => $row['department'],
			'programme' => $row['programme'],
			'session_name' => $row['session_name'],
			'status' => $row['status'],
			'similarity' => (int)round($score),
			'exact_duplicate' => ($normalizedTopic === normalize_topic_text($row['title']))
		];
	}
	usort($matches, function($a, $b) {
		if ($a['exact_duplicate'] !== $b['exact_duplicate']) { return $a['exact_duplicate'] ? -1 : 1; }
		if ($a['similarity'] === $b['similarity']) { return 0; }
		return $a['similarity'] < $b['similarity'] ? 1 : -1;
	});
	$matches = array_slice($matches, 0, (int)$limit);
	return $matches;
}

function topic_check_summary($matches, $topic) {
	if (empty($matches)) {
		return [
			'status' => 'no_match',
			'message' => 'No closely related research topic was found.',
			'detail' => 'This result is only a basic topic similarity check and does not constitute a plagiarism determination.'
		];
	}
	$first = $matches[0];
	if ($first['exact_duplicate']) {
		return [
			'status' => 'duplicate',
			'message' => 'Exact or duplicate topic found.',
			'detail' => 'An exact or duplicate research title already exists in the repository.'
		];
	}
	if ($first['similarity'] >= 90) {
		return [
			'status' => 'very_high',
			'message' => 'Potentially related research topics found.',
			'detail' => 'A highly similar research topic was found.'
		];
	}
	if ($first['similarity'] >= 70) {
		return [
			'status' => 'high',
			'message' => 'Potentially related research topics found.',
			'detail' => 'A highly similar research topic was found.'
		];
	}
	if ($first['similarity'] >= 50) {
		return [
			'status' => 'moderate',
			'message' => 'Potentially related research topics found.',
			'detail' => 'Some related research topics were found.'
		];
	}
	return [
		'status' => 'no_match',
		'message' => 'No closely related research topic was found.',
		'detail' => 'This result is only a basic topic similarity check and does not constitute a plagiarism determination.'
	];
}
