<?php
require __DIR__ . '/../config/functions.php';
require_student();
$studentUser = current_user();
$uid = $studentUser['id'];
$stmt = $pdo->prepare("SELECT s.id,s.matric_number,COUNT(r.id) total,SUM(r.status='PENDING') pending,SUM(r.status='APPROVED') approved,SUM(r.status='REJECTED') rejected FROM students s LEFT JOIN research_projects r ON r.student_id=s.id WHERE s.user_id=? GROUP BY s.id");
$stmt->execute([$uid]);
$stats = $stmt->fetch();
$stmt = $pdo->prepare("SELECT r.*,c.name category,a.name session_name FROM research_projects r LEFT JOIN research_categories c ON c.id=r.category_id LEFT JOIN academic_sessions a ON a.id=r.session_id JOIN students s ON s.id=r.student_id WHERE s.user_id=? ORDER BY r.updated_at DESC LIMIT 8");
$stmt->execute([$uid]);
$rows = $stmt->fetchAll();
$totalSubmissions = isset($stats['total']) ? $stats['total'] : 0;
$pending = isset($stats['pending']) ? $stats['pending'] : 0;
$approved = isset($stats['approved']) ? $stats['approved'] : 0;
$rejected = isset($stats['rejected']) ? $stats['rejected'] : 0;
$pageTitle = 'Student dashboard';
require __DIR__ . '/../includes/header.php';
?>
<section class="mx-auto max-w-7xl px-5 py-10"><div class="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p class="text-sm font-bold uppercase tracking-widest text-leaf">Student workspace</p><h1 class="mt-2 text-3xl font-black text-forest">Welcome, <?= e($studentUser['name']) ?></h1></div><a href="/001/student/research/create.php" class="rounded-lg bg-forest px-5 py-3 text-center font-bold text-white">Upload research</a></div><div class="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4"><div class="rounded-xl bg-white p-5"><span class="text-sm text-slate-500">Total submissions</span><b class="mt-2 block text-3xl text-forest"><?= (int)$totalSubmissions ?></b></div><div class="rounded-xl bg-white p-5"><span class="text-sm text-slate-500">Pending</span><b class="mt-2 block text-3xl text-amber-600"><?= (int)$pending ?></b></div><div class="rounded-xl bg-white p-5"><span class="text-sm text-slate-500">Approved</span><b class="mt-2 block text-3xl text-green-700"><?= (int)$approved ?></b></div><div class="rounded-xl bg-white p-5"><span class="text-sm text-slate-500">Rejected</span><b class="mt-2 block text-3xl text-red-700"><?= (int)$rejected ?></b></div></div><div class="mt-10 overflow-hidden rounded-xl border border-emerald-100 bg-white"><div class="flex items-center justify-between border-b p-5"><h2 class="font-bold text-forest">Recent submissions</h2><a href="/001/student/research/index.php" class="text-sm font-bold text-leaf">View all</a></div><div class="overflow-x-auto"><table class="w-full text-left text-sm"><thead class="bg-mist text-xs uppercase text-slate-500"><tr><th class="p-4">Title</th><th class="p-4">Category</th><th class="p-4">Status</th><th class="p-4">Action</th></tr></thead><tbody><?php foreach ($rows as $row): ?><tr class="border-t border-slate-100"><td class="p-4 font-semibold text-forest"><?= e($row['title']) ?></td><td class="p-4 text-slate-500"><?= e(isset($row['category']) ? $row['category'] : '') ?></td><td class="p-4"><span class="<?= e(status_class($row['status'])) ?>"><?= e($row['status']) ?></span></td><td class="p-4"><a class="font-bold text-leaf" href="/001/student/research/create.php?id=<?= (int)$row['id'] ?>">Manage</a></td></tr><?php endforeach; if (!$rows): ?><tr><td class="p-6 text-slate-500" colspan="4">You have not submitted any research yet.</td></tr><?php endif; ?></tbody></table></div></div></section><?php require __DIR__ . '/../includes/footer.php'; ?>