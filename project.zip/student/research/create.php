<?php
require __DIR__ . '/../../config/functions.php';
require_student();
$studentUser = current_user();
$uid = $studentUser['id'];
$studentQuery = $pdo->prepare('SELECT * FROM students WHERE user_id=?');
$studentQuery->execute([$uid]);
$studentRecord = $studentQuery->fetch();
$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
$existing = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT r.* FROM research_projects r WHERE r.id=? AND r.student_id=?');
    $stmt->execute([$id, $studentRecord['id']]);
    $existing = $stmt->fetch();
    if (!$existing || $existing['status'] === 'APPROVED') { redirect('/001/student/research/index.php'); }
}
$categories = $pdo->query("SELECT id,name FROM research_categories WHERE status='active' ORDER BY name")->fetchAll();
$departments = $pdo->query("SELECT id,name FROM departments WHERE status='active' ORDER BY name")->fetchAll();
$programmes = $pdo->query("SELECT id,name,department_id FROM programmes WHERE status='active' ORDER BY name")->fetchAll();
$supervisors = $pdo->query("SELECT id,name,department_id FROM supervisors WHERE status='active' ORDER BY name")->fetchAll();
$sessions = $pdo->query("SELECT id,name FROM academic_sessions WHERE status='active' ORDER BY name DESC")->fetchAll();
$error = '';
$topicCheckMessage = '';
$topicCheckType = '';
$topicCheckResults = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_topic'])) {
    verify_csrf();
    $topicCheckText = isset($_POST['title_for_check']) ? trim((string)$_POST['title_for_check']) : '';
    if ($topicCheckText === '') {
        $topicCheckMessage = 'Please enter a research topic to continue.';
        $topicCheckType = 'error';
    } else {
        $departmentForCheck = !empty($studentRecord['department_id']) ? (int)$studentRecord['department_id'] : 0;
        $sessionForCheck = !empty($studentRecord['session_id']) ? (int)$studentRecord['session_id'] : 0;
        $topicCheckResults = find_similar_research_topics($topicCheckText, $departmentForCheck, $sessionForCheck, 10, 50);
        $topicCheckSummary = topic_check_summary($topicCheckResults, $topicCheckText);
        $topicCheckMessage = $topicCheckSummary['message'];
        $topicCheckType = $topicCheckSummary['status'];
        $topicCheckDetail = $topicCheckSummary['detail'];
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['check_topic'])) {
    verify_csrf();
    $title = trim(isset($_POST['title']) ? $_POST['title'] : '');
    $abstract = trim(isset($_POST['abstract']) ? $_POST['abstract'] : '');
    $keywords = trim(isset($_POST['keywords']) ? $_POST['keywords'] : '');
    if (!$title || !$abstract || !$keywords) {
        $error = 'Title, abstract and keywords are required.';
    } elseif (!$id && (!isset($_FILES['pdf']) || $_FILES['pdf']['error'] === UPLOAD_ERR_NO_FILE)) {
        $error = 'Please select a PDF document.';
    } else {
        try {
            $filename = $existing && isset($existing['pdf_filename']) ? $existing['pdf_filename'] : null;
            $original = $existing && isset($existing['original_filename']) ? $existing['original_filename'] : '';
            if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] !== UPLOAD_ERR_NO_FILE) {
                $file = $_FILES['pdf'];
                $max = 10 * 1024 * 1024;
                $mime = function_exists('finfo_open') ? (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']) : $file['type'];
                if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > $max || $mime !== 'application/pdf' || strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'pdf') {
                    throw new Exception('Invalid PDF. Files must be PDF and 10MB or smaller.');
                }
                if (function_exists('random_bytes')) { $randomName = bin2hex(random_bytes(16)); } elseif (function_exists('openssl_random_pseudo_bytes')) { $randomName = bin2hex(openssl_random_pseudo_bytes(16)); } else { $randomName = sha1(uniqid(mt_rand(), true)); }
                $filename = $randomName . '.pdf';
                $original = clean_filename($file['name']);
                if (!is_dir(__DIR__ . '/../../uploads/research')) { mkdir(__DIR__ . '/../../uploads/research', 0755, true); }
                if (!move_uploaded_file($file['tmp_name'], __DIR__ . '/../../uploads/research/' . $filename)) { throw new Exception('Unable to save uploaded PDF.'); }
            }
            $departmentId = !empty($_POST['department_id']) ? $_POST['department_id'] : null;
            $programmeId = !empty($_POST['programme_id']) ? $_POST['programme_id'] : null;
            $categoryId = !empty($_POST['category_id']) ? $_POST['category_id'] : null;
            $supervisorId = !empty($_POST['supervisor_id']) ? $_POST['supervisor_id'] : null;
            $sessionId = !empty($_POST['session_id']) ? $_POST['session_id'] : null;
            $academicError = validate_academic_selection($departmentId, $programmeId, $supervisorId, $categoryId, $sessionId);
            if ($academicError !== '') { throw new Exception($academicError); }
            $studentValidation = validate_research_submission((int)$studentRecord['id'], $departmentId, $programmeId, $supervisorId, $sessionId);
            if ($studentValidation !== '') { throw new Exception($studentValidation); }
            $data = [$title, $abstract, $keywords, $departmentId, $programmeId, $categoryId, $supervisorId, $sessionId];
            $researchId = 0;
            if ($id) {
                $sql = "UPDATE research_projects SET title=?,abstract=?,keywords=?,department_id=?,programme_id=?,category_id=?,supervisor_id=?,session_id=?,status='PENDING',rejection_reason=NULL,rejected_at=NULL";
                $args = $data;
                if ($filename) { $sql .= ',pdf_filename=?,original_filename=?'; $args[] = $filename; $args[] = $original; }
                $sql .= ' WHERE id=? AND student_id=?';
                $args[] = $id; $args[] = $studentRecord['id'];
                $pdo->prepare($sql)->execute($args);
                $researchId = (int)$id;
                log_activity($uid, 'UPDATE_RESEARCH', 'Updated research #' . $id);
            } else {
                $sql = 'INSERT INTO research_projects (student_id,title,abstract,keywords,department_id,programme_id,category_id,supervisor_id,session_id,pdf_filename,original_filename) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_merge([$studentRecord['id']], $data, [$filename, $original]));
                $researchId = (int)$pdo->lastInsertId();
                log_activity($uid, 'UPLOAD_RESEARCH', 'Submitted research');
            }
            if ($researchId > 0) {
                $departmentName = $pdo->prepare('SELECT name FROM departments WHERE id=? LIMIT 1');
                $departmentName->execute([$departmentId]);
                $departmentValue = (string)$departmentName->fetchColumn();
                $sessionName = $pdo->prepare('SELECT name FROM academic_sessions WHERE id=? LIMIT 1');
                $sessionName->execute([$sessionId]);
                $sessionValue = (string)$sessionName->fetchColumn();
                $studentUserName = (string)$studentUser['name'];
                notify_admins_of_research_submission($researchId, $title, $departmentValue, $sessionValue, $studentUserName);
            }
            flash('success', 'Research submitted successfully.');
            redirect('/001/student/research/index.php');
        } catch (Exception $exception) { $error = $exception->getMessage(); }
    }
}
$pageTitle = $id ? 'Edit research' : 'Upload research';
require __DIR__ . '/../../includes/header.php';
?>
<section class="mx-auto max-w-4xl px-5 py-10"><div class="rounded-2xl border border-emerald-100 bg-white p-7"><p class="text-sm font-bold uppercase tracking-widest text-leaf">Student workspace</p><h1 class="mt-2 text-3xl font-black text-forest"><?= $id ? 'Edit research' : 'Submit research' ?></h1><?php if ($error): ?><div class="mt-5 rounded-lg bg-red-50 p-3 text-sm text-red-700"><?= e($error) ?></div><?php endif; ?><form method="post" class="mt-6 rounded-xl border border-emerald-100 bg-emerald-50 p-4"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="check_topic" value="1"><div class="grid gap-3 md:grid-cols-[1fr_auto]"><div><label class="text-sm font-semibold">Research title</label><textarea name="title_for_check" rows="3" class="field mt-2" placeholder="Enter proposed research topic..."><?= e((isset($_POST['title_for_check']) ? $_POST['title_for_check'] : ($existing ? $existing['title'] : '')) ) ?></textarea></div><button type="submit" class="self-end rounded-lg bg-forest px-4 py-3 font-bold text-white">Check Topic Availability</button></div><?php if (isset($_POST['check_topic'])): ?><div class="mt-4 rounded-xl border border-emerald-200 bg-white p-4"><?php if ($topicCheckMessage): ?><h3 class="text-sm font-bold uppercase tracking-wider text-forest"><?= e($topicCheckMessage) ?></h3><?php endif; ?><?php if ($topicCheckType !== 'error' && $topicCheckResults): ?><div class="mt-3 overflow-hidden rounded-lg border border-slate-200"><table class="w-full text-left text-sm"><thead class="bg-mist text-xs uppercase text-slate-500"><tr><th class="p-3">Research Title</th><th class="p-3">Department</th><th class="p-3">Similarity</th><th class="p-3">Status</th><th class="p-3">Action</th></tr></thead><tbody><?php foreach ($topicCheckResults as $result): ?><tr class="border-t border-slate-100"><td class="p-3 font-medium text-forest"><?= e($result['title']) ?></td><td class="p-3"><?= e($result['department'] ?: 'N/A') ?></td><td class="p-3"><span class="rounded-full bg-amber-100 px-2 py-1 text-xs font-bold text-amber-700"><?= (int)$result['similarity'] ?>%</span></td><td class="p-3"><span class="<?= e(status_class($result['status'])) ?>"><?= e($result['status']) ?></span></td><td class="p-3"><a href="/001/research-details.php?id=<?= (int)$result['id'] ?>" class="rounded-lg bg-forest px-3 py-2 font-bold text-white">View</a></td></tr><?php endforeach; ?></tbody></table></div><?php elseif ($topicCheckType !== 'error'): ?><p class="mt-3 text-sm text-slate-600">No closely related research topic was found. Note: This tool provides a basic similarity check and does not determine plagiarism.</p><?php endif; ?></div><?php endif; ?></form><form method="post" enctype="multipart/form-data" class="mt-6 grid gap-4 md:grid-cols-2"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><label class="text-sm font-semibold md:col-span-2">Research title<input required name="title" value="<?= e($existing ? $existing['title'] : '') ?>" class="field mt-2"></label><label class="text-sm font-semibold md:col-span-2">Abstract<textarea required name="abstract" rows="6" class="field mt-2"><?= e($existing ? $existing['abstract'] : '') ?></textarea></label><label class="text-sm font-semibold">Keywords<input required name="keywords" value="<?= e($existing ? $existing['keywords'] : '') ?>" class="field mt-2"></label><label class="text-sm font-semibold">Category<select required name="category_id" class="field mt-2"><option value="">Select category</option><?php foreach ($categories as $option): ?><option value="<?= $option['id'] ?>" <?= $existing && $existing['category_id'] == $option['id'] ? 'selected' : '' ?>><?= e($option['name']) ?></option><?php endforeach; ?></select></label><?php $selects = [['department_id', 'Department', $departments], ['programme_id', 'Programme', $programmes], ['supervisor_id', 'Supervisor', $supervisors], ['session_id', 'Academic session', $sessions]]; foreach ($selects as $select): $field = $select[0]; $label = $select[1]; $options = $select[2]; ?><label class="text-sm font-semibold"><?= e($label) ?><select required name="<?= e($field) ?>" class="field mt-2"><option value="">Select <?= e(strtolower($label)) ?></option><?php foreach ($options as $option): ?><option value="<?= $option['id'] ?>" <?= $existing && $existing[$field] == $option['id'] ? 'selected' : '' ?>><?= e($option['name']) ?></option><?php endforeach; ?></select></label><?php endforeach; ?><label class="text-sm font-semibold md:col-span-2">Research PDF <span class="font-normal text-slate-500">(maximum 10MB)</span><input <?= $id ? '' : 'required' ?> type="file" name="pdf" accept="application/pdf" class="field mt-2"></label><button class="rounded-lg bg-forest px-4 py-3 font-bold text-white md:col-span-2">Save submission</button></form></div></section><?php require __DIR__ . '/../../includes/footer.php'; ?>