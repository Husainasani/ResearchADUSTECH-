<?php
require __DIR__ . '/config/functions.php';
$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
$stmt = $pdo->prepare("SELECT r.*,u.name author,u.email,s.matric_number,s.user_id,d.name department,p.name programme,c.name category,su.name supervisor,a.name session_name FROM research_projects r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id LEFT JOIN departments d ON d.id=r.department_id LEFT JOIN programmes p ON p.id=r.programme_id LEFT JOIN research_categories c ON c.id=r.category_id LEFT JOIN supervisors su ON su.id=r.supervisor_id LEFT JOIN academic_sessions a ON a.id=r.session_id WHERE r.id=?");
$stmt->execute([$id]);
$row = $stmt->fetch();
if (!$row) { http_response_code(404); require __DIR__ . '/404.php'; exit; }
$viewer = current_user();
$canView = $row['status'] === 'APPROVED';
$isOwner = $viewer && $viewer['role'] === 'student' && (int)$row['user_id'] === (int)$viewer['id'];
$isAdmin = $viewer && $viewer['role'] === 'admin';
if ($isOwner || $isAdmin) { $canView = true; }
if (!$canView) {
	$pageTitle = 'Research not publicly available';
	require __DIR__ . '/includes/header.php';
	?><section class="mx-auto max-w-xl px-5 py-24 text-center"><p class="text-sm font-bold uppercase tracking-widest text-leaf">Research repository</p><h1 class="mt-3 text-3xl font-black text-forest">Research not publicly available</h1><p class="mt-4 leading-7 text-slate-600"><?= $row['status'] === 'PENDING' ? 'This research is still under administrative review.' : 'This research is not currently available in the public repository.' ?></p><a class="mt-7 inline-block rounded-lg bg-forest px-5 py-3 font-bold text-white" href="/001/research.php">Browse approved research</a></section><?php require __DIR__ . '/includes/footer.php'; exit;
}
$category = isset($row['category']) ? $row['category'] : 'Research';
$department = isset($row['department']) ? $row['department'] : '';
$programme = isset($row['programme']) ? $row['programme'] : '';
$sessionName = isset($row['session_name']) ? $row['session_name'] : '';
$level = isset($row['level']) ? $row['level'] : '';
$supervisor = isset($row['supervisor']) ? $row['supervisor'] : '';
$status = $row['status'];
$pageTitle = $row['title'];
require __DIR__ . '/includes/header.php';
?>
<section class="mx-auto max-w-5xl px-5 py-12"><a href="/001/research.php" class="text-sm font-bold text-leaf">&larr; Back to research</a><div class="mt-5 rounded-2xl border border-emerald-100 bg-white p-6 md:p-10"><div class="flex flex-wrap items-start justify-between gap-3"><span class="text-xs font-bold uppercase tracking-widest text-leaf"><?= e($category) ?></span><span class="<?= e(status_class($status)) ?>"><?= e($status) ?></span></div><h1 class="mt-3 text-3xl font-black leading-tight text-forest md:text-5xl"><?= e($row['title']) ?></h1><div class="mt-6 grid gap-4 border-y border-slate-100 py-6 text-sm md:grid-cols-3"><div><span class="block text-slate-400">Author</span><b><?= e($row['author']) ?></b></div><?php if ($isOwner || $isAdmin): ?><div><span class="block text-slate-400">Matric Number</span><b><?= e($row['matric_number']) ?></b></div><?php endif; ?><div><span class="block text-slate-400">Department</span><b><?= e($department) ?></b></div><div><span class="block text-slate-400">Session</span><b><?= e($sessionName) ?></b></div><div><span class="block text-slate-400">Programme</span><b><?= e($programme) ?></b></div><?php if ($isOwner || $isAdmin): ?><div><span class="block text-slate-400">Level</span><b><?= e($level) ?></b></div><?php endif; ?><div><span class="block text-slate-400">Supervisor</span><b><?= e($supervisor) ?></b></div><div><span class="block text-slate-400">Submitted</span><b><?= e($row['submitted_at']) ?></b></div></div><h2 class="text-sm font-bold uppercase tracking-widest text-leaf">Abstract</h2><p class="mt-3 whitespace-pre-line leading-8 text-slate-600"><?= e($row['abstract']) ?></p><p class="mt-6 text-sm text-slate-500"><b>Keywords:</b> <?= e($row['keywords']) ?></p><?php if ($status === 'REJECTED'): ?><div class="mt-6 rounded-lg bg-red-50 p-4 text-sm text-red-800"><b>Rejection reason:</b><p class="mt-1"><?= e($row['rejection_reason']) ?></p><?php if ($isOwner): ?><a class="mt-3 inline-block font-bold text-red-900" href="/001/student/research/create.php?id=<?= $id ?>">Edit &amp; resubmit</a><?php endif; ?></div><?php endif; ?><div class="mt-8 flex flex-wrap gap-3"><?php if ($status === 'APPROVED' || $isOwner || $isAdmin): ?><a target="_blank" href="/001/download.php?id=<?= $id ?>&view=1" class="rounded-lg border border-forest px-5 py-3 font-bold text-forest">View PDF</a><a href="/001/download.php?id=<?= $id ?>" class="rounded-lg bg-forest px-5 py-3 font-bold text-white">Download PDF</a><?php endif; ?><?php if ($isAdmin): ?><form method="post" action="/001/admin/research/action.php"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="approve"><button class="rounded-lg bg-green-700 px-5 py-3 font-bold text-white">Approve</button></form><a href="/001/admin/research/action.php?id=<?= $id ?>&reject=1" class="rounded-lg bg-amber-600 px-5 py-3 font-bold text-white">Reject</a><?php endif; ?></div></div></section><?php require __DIR__ . '/includes/footer.php'; ?>