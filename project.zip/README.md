# ADUSTECH Research Repository

A database-driven PHP/MySQL repository for undergraduate research at Aliko Dangote University of Science and Technology, Wudil.

## Features

- Public approved-research search, details, PDF preview and tracked downloads
- Student registration with unique email and matric number
- Student dashboard, profile, password change, PDF upload and rejected-project resubmission
- Admin dashboard with live counts, research review, approval/rejection reasons, student list and activity logs
- PDO prepared statements, password hashing, sessions, CSRF tokens, output escaping and PDF validation

## Requirements

AppServ with Apache, PHP 7.1+ and MySQL. This installation is configured to use `C:\AppServ\php7\` because the application uses PHP 7 syntax. The project uses Tailwind CDN and Lucide CDN, so an internet connection is useful for styling/icons; the PHP application itself has no package build step.

## Installation

1. Copy this folder to `C:\AppServ\www\001` (or rename it to `research-repository` and adjust the `/001/` base paths in the shared files).
2. Start Apache and MySQL from AppServ.
3. Open phpMyAdmin and import `database.sql`. The script creates the `research_repository` database and sample catalog data.
4. Check `config/database.php` and set the host, database, user and password for your AppServ installation.
5. Ensure `uploads/research` is writable by Apache.
6. Open `http://localhost/001/`.

## Default administrator

- Email: `admin@adustech.edu.ng`
- Password: `password`

Change this password after first login by updating the password-change flow or directly using a temporary PHP script with `password_hash()`.

## Structure

- `config/`: PDO, sessions, authorization and shared helpers
- `auth/`: login, registration and logout
- `student/`: student dashboard and submission workflows
- `admin/`: dashboard, review queue, students, profile and logs
- `admin/academic.php`: shared CRUD engine for departments, programmes, supervisors, sessions and categories
- `admin/departments/`, `admin/programmes/`, `admin/supervisors/`, `admin/sessions/`, `admin/categories/`: dedicated academic-management routes
- `api/`: dependent programme and supervisor JSON endpoints
- `uploads/research/`: generated PDF filenames only
- `database.sql`: schema, indexes, foreign keys and sample catalog data

## PHP configuration

For larger PDFs, increase `upload_max_filesize` and `post_max_size` in `php.ini` while keeping the application limit at 10MB unless there is a clear reason to change it. Enable the Fileinfo extension for MIME validation. Existing databases can be upgraded with `database-migration-academic.sql`; fresh imports receive the academic columns from `database.sql`.

## Security notes

PDFs are renamed with random server filenames. Only approved projects are delivered by `download.php`; downloads are recorded with user, IP and user-agent data. Never expose database credentials or enable verbose PHP errors in production. Review the sample credentials before demonstration.
